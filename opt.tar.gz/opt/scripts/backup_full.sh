#!/bin/bash

show_help() {
    echo "Uso:"
    echo "  backup_full.sh ORIGEN DESTINO"
    echo
    echo "Ejemplo:"
    echo "  backup_full.sh /var/log /backup_dir"
    echo
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
}

if [ "$1" == "-help" ]; then
    show_help
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: cantidad incorrecta de argumentos."
    show_help
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino no existe."
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup realizado correctamente: $DESTINO/$ARCHIVO"
else
    echo "Error al realizar el backup."
    exit 1
fi

